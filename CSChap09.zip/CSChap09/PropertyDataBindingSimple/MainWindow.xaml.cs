﻿using System.Windows;

namespace PropertyDataBindingSimple
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public class Person
        {   
            public string Name { get; set; }
        }

        Person person = new Person();

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = person;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(person.Name);
        }
    }
}
