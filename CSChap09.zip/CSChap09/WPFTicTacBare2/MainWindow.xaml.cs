﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFTicTacBare
{
    public enum Player
    {
        None, X, O
    }

    public partial class MainWindow : Window
    {
        private readonly Image[,] imageControls = new Image[3, 3];
        //public Player[,]? GameGridArray { get; private set; }  // Contains X,O,none. This mirrors the grid of image holders.
        
        Player[,] myGameGrid = new Player[3, 3]; 

        Player player = new Player();
        public MainWindow()
        {
            InitializeComponent();

            SetupGameGrid();   // Step 1 : Set up a 9 x 9 array of image holders - and GridArray.
        
            player = Player.X;   // X goes first always.  

            
        }

        private void testForWin()
        {
            for (int r = 0; r < 3; r++)

                for (int c = 0; c < 3; c++)

                    MessageBox.Show(myGameGrid[r, c].ToString());


            //myGameGrid[0, 0] = Player.X;
        }
    private void GameGrid_MouseDown(object sender, MouseButtonEventArgs e)
    {
        // Determines the row and column of the grid.
        double squareSize = GameGrid.Width / 3; // 300/3 = 100

        Point clickPosition = e.GetPosition(GameGrid);// Mouse coords.  eg 49.2,38.5

        int row = (int)(clickPosition.Y / squareSize); // eg 38.5/100 -> 0 In WPF top to bottom.

        int col = (int)(clickPosition.X / squareSize); // eg 49.2/100 -> 0 Left to Right.

        // Step 2 : Draws an X or O at that grid coordinate.

        if (player == Player.X)
        imageControls[row, col].Source = new BitmapImage(new Uri("pack://application:,,,/Assets/X15.png"));

        else if (player == Player.O)
        imageControls[row, col].Source = new BitmapImage(new Uri("pack://application:,,,/Assets/O15.png"));

        myGameGrid[row, col] = player; // This array mirrors the XAML Image array.

        // testForWin();      

        player = player == Player.X ? Player.O : Player.X; // X <-> O .  // Next (2nd) time round it will be an O.

        }

        // Allocates 9 image controls to the grid.
        private void SetupGameGrid() // 9 IMAGE CONTROLS
        { // Nothing drawn yet.
            for (int r = 0; r < 3; r++)
            {
                // Sets up 9 image controls - not images!
                for (int c = 0; c < 3; c++)
                {
                    Image imageControl = new Image();

                    GameGrid.Children.Add(imageControl); // Dont forget to add them to the UI.

                    Player CurrentPlayer = Player.X; // Player X starts.

                    imageControls[r, c] = imageControl; // An array of image controls.

                    myGameGrid[r, c] = Player.None;  // 
                }
            }
        }
    }
}
