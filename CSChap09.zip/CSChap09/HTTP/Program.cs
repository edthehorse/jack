﻿

namespace HTTP
{
    internal class Program
    {
        static  async void  Main(string[] args)
        {
            Console.WriteLine(await new HttpClient().GetStringAsync("http://localhost:51111/MyApp/Request.txt"));
        }
    }
}