﻿namespace BinaryFiles
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string path = @"c:\temp\binFile";

            if (File.Exists(path))
            {
                File.Delete(path);
            }




            FileStream myFile = new FileStream(path, FileMode.CreateNew);

            BinaryWriter bwFile = new BinaryWriter(myFile);

            // Write data
            for (int i = 0; i < 10; i++)
            {
                bwFile.Write(i);
            }
            bwFile.Close();
            myFile.Close();

        }
    }
}



//using System;
//using System.IO;

//class MyStream
//{
//    public static void Main()
//    {
//        string path = @"c:\temp\binFile";

//        FileStream myFile = new FileStream(path, FileMode.Open);

//        BinaryReader br = new BinaryReader(myFile);

//        // Read data
//        for (int i = 0; i < (int)br.BaseStream.Length / sizeof(int); i++)
//        {
//            int b = br.ReadInt32();

//            Console.WriteLine(b);
//        }

//        br.Close();
//    }
//}





