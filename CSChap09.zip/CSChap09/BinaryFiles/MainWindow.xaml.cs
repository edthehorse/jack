﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BinaryFiles
{
   
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        

        private void cmdWriteBinary_Click(object sender, RoutedEventArgs e)
        {
            
            string path = @"c:\temp\binFile"; 
            
            if (File.Exists(path))
            {   File.Delete(path);   }

            FileStream myFile = new FileStream(path, FileMode.CreateNew);

            BinaryWriter bwFile = new BinaryWriter(myFile);

            // Write data
            for (int i = 0; i < 10; i++)
            {  bwFile.Write(i);    }

            bwFile.Close();
            myFile.Close();
        }

        private void cmdReadBinary_Click(object sender, RoutedEventArgs e)
        {
            string path = @"c:\temp\binFile";

            FileStream myFile = new FileStream(path, FileMode.Open);

            BinaryReader br = new BinaryReader(myFile);

            // Read data
            for (int i = 0; i < (int)br.BaseStream.Length / sizeof(int); i++)
            {
                int b = br.ReadInt32();

                Console.WriteLine(b);
            }
            br.Close();
        }
    }
}





   

