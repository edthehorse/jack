﻿
// TEXT FILE WRITE

namespace FileHandling
{
    using System;
    using System.IO;
    public class Writing
    {
        public static void Main()
        {
            StreamWriter myFile = File.CreateText("C:\\temp\\text.txt");
            myFile.WriteLine("about ttime");
            myFile.Close();
        }
    }
}


// TEXT FILE READ

//using System;
//using System.IO;

//class Test
//{
//    public static void Main()
//    {
//        string path = @"c:\temp\text.txt";

//        StreamReader sr = new StreamReader(path);
//        {
//            while (sr.Peek() >= 0)
//            {
//                Console.WriteLine(sr.ReadLine());
//            }
//        }
//    }
//}



//using System;
//using System.IO;

//class Test
//{
//    public static void Main()
//    {
//        string path = @"c:\text.txt";
//        try
//        {
//            if (File.Exists(path))
//            {
//                File.Delete(path);
//            }
//            using (StreamWriter sw = new StreamWriter(path))
//            {
//                sw.WriteLine("about time");

//            }
//            using (StreamReader sr = new StreamReader(path))
//            {
//                while (sr.Peek() >= 0)
//                {
//                    Console.WriteLine(sr.ReadLine());
//                }
//            }
//        }
//        catch (Exception e)
//        {
//            Console.WriteLine("The process failed: {0}", e.ToString());
//        }
//        finally
//        {

//        }
//    }
//}





