﻿namespace Exceptions
{

    using System;
    internal class Program
    {
        static void Main(string[] args)
        {

         int y = 6;   int x = 0; 

            try
            {
            int z = y/x;
          
            Console.WriteLine(x.ToString());
            }

            catch (DivideByZeroException e))
            {
                Console.WriteLine("Dont even think about dividing by Zero.");
            }
            
            catch (Exception e)
            {
                Console.WriteLine($"ERROR:  {e} ")  ;
            }


            finally
            {
                Console.WriteLine("Always do this what ever.");
            }

            Console.WriteLine("And this");
        }


    }
}
