﻿namespace Exceptions
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string? s = "Hello";   // ? means nullable.

            try
            {
                Console.WriteLine(s.ToUpper());
            }

            catch (Exception e)
            {
                Console.WriteLine(e);
            }


            finally
            {
                Console.WriteLine("finally");
            }

            Console.WriteLine("Done");
        }


    }
}
