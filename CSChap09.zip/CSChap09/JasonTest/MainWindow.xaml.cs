﻿
using System.Windows;


namespace JasonTest
{
   
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Grid_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            {
                Point P = e.GetPosition(GameGrid);

                MessageBox.Show($"X = {P.X.ToString()} Y = {P.Y.ToString()}");
            }

        }
    }
}
