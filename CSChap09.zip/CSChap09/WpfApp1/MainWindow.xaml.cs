﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //CreateALine();

        }

        private void myHandler(object sender, RoutedEventArgs e)
        {

        }

        public void CreateALine()
        {
            // Create a Line
            Line redLine = new Line();
            redLine.X1 = 50;
            redLine.Y1 = 50;
            redLine.X2 = 200;
            redLine.Y2 = 200;

            // Create a red Brush
            SolidColorBrush redBrush = new SolidColorBrush();
            redBrush.Color = Colors.Red;


            // Set Line's width and color
            redLine.StrokeThickness = 4;
            redLine.Stroke = redBrush;

            // Add line to the Grid.
            Layout.Children.Add(redLine);
        }





    }
}
