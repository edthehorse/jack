﻿namespace XML
{
    using System;
    using System.IO;
    using System.Xml.Serialization;

    // This is the class that will be serialized.
    public class Table1
    {
        public string? Name;
        public decimal Balance;
    }
    public class Test
    {
        public static void Main()
        {
            Stream writer = new FileStream("c:\\temp\\test.xml", FileMode.Create);

            XmlSerializer serializer = new XmlSerializer(typeof(Table1));

            Table1 t1 = new Table1();
            t1.Name = "ed";
            t1.Balance = 10;

            serializer.Serialize(writer, t1);
            writer.Close();
        }
    }

}