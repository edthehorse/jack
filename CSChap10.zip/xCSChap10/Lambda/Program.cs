﻿namespace Lambda
{
    internal class Program
    {
        static void Main()
        {
            Func<int, int> arith = (int a) => a * a;

            Console.WriteLine(arith(5)); // -> 25



            //Func<int, int,int> arith = (int a, int b) => { return a * b; };

            //Console.WriteLine(arith(2, 3));

            //Action arith = () => Console.WriteLine("Hello");
            //arith();


            Func<int, int> sqr = x => x * x;
            int y = sqr(3);
            Console.WriteLine(y);


        }
    }
}