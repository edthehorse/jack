﻿
using System;
using System.Text;

namespace ConsoleApp1
{
    using System;

    public class Example
    {
        public static void Main()
        {
            // Define a byte array.
            byte[] bytes = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };

            // Convert the byte array to a base 64 string.
            string s = Convert.ToBase64String(bytes);
            Console.WriteLine("The base 64 string:\n   {0}\n", s); // AgQG... etc

            // Restore the byte array to 64 string.
            byte[] newBytes = Convert.FromBase64String(s); 
            Console.WriteLine("The restored byte array: ");
            Console.WriteLine("   {0}\n", BitConverter.ToString(newBytes));// bytes as above
        }
    }
   
    //     The base 64 string:
    //        AgQGCAoMDhASFA==
}
