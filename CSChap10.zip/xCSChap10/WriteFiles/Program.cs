﻿using System.Diagnostics;

namespace WriteFiles
{
  
    internal class Program
    {
        static async Task Main()
        {
            string st = "ed the horse";

            //var sw = new Stopwatch();

            //sw.Start();

            var task1 = File.WriteAllTextAsync(@"C:\X\data1.txt",st);
            var task2 = File.WriteAllTextAsync(@"C:\X\data2.txt",st);
            var task3 = File.WriteAllTextAsync(@"C:\X\data3.txt",st);
            var task4 = File.WriteAllTextAsync(@"C:\X\data4.txt",st);

            var tasks = new Task[] { task1, task2, task3, task4 };

            Task.WaitAll(tasks);

            //sw.Stop();

            //var elapsed = sw.ElapsedMilliseconds;

            //Console.WriteLine($"elapsed: {elapsed} ms");

            //await task1;
            //await task2;
            //await task3;
            //await task4;
        }
    }
}