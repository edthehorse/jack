﻿using System;

class Item<T>
{
    public T? price { get; set; }
    public T push(T x)
    {
        return x;
    }

}

class Program
{
    static void Main()
    {
        Item<int> i1 = new Item<int>();

        Item<double> d1 = new Item<double>();

        Console.WriteLine(d1.push(3.0));

    }
}



