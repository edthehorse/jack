﻿using System;
using System.Collections;

class Test
{
    static void Main()
    {
        ArrayList list = new ArrayList();

        list.Add(45);
        list.Add(87);
        list.Add(12);
        list.Add(100);

        list.Remove(87); // the actual element 87
        list.RemoveAt(0);

        Console.WriteLine("I have {0}", list.Count);
        Console.WriteLine("I could have {0}", list.Capacity);
        Console.WriteLine("{0} is at position {1}\n", 12, list.IndexOf(12));

        foreach (int num in list)
        {
            Console.WriteLine(num);
        }
    }
}
