﻿namespace List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> primes = new List<int> { 1, 2, 3, 5, 7 };

            primes.Add(1); // 1 to the end
            primes.Remove(5); // removes the 5.
            primes.Insert(2,9); // 9 at position 2. 

            foreach (var e in primes)
                Console.Write(e.ToString()+ " "); //  1 2 9 3 7

            var res = from s in primes
                         where s == 1
                         select s;

            foreach (var e in res)
                Console.Write(e.ToString()+ " "); // 1 1
        }
    }
}