using BlazorAppDemo.Data;

namespace BlazorAppDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddRazorPages(); // This bit loads the Counter,razor to the server.

            builder.Services.AddServerSideBlazor();

            builder.Services.AddSingleton<MyWeatherForecastService>();
            // ie place this WeatherForecastService Class code onto the server !
            // Why dont we have to do this for the Counter class? 
            // cOUNTER IS A rAZOR PAGE IE CODE IS EMBEDDED (and uploaded as above AddRazorPages() -  whereas take a look at MyWeatherForecastService - it is simply a code class sheet! - containing data! (Notice that its in the Data folder!)

            var app = builder.Build();

            // Configure the HTTP request pipeline.

            if (!app.Environment.IsDevelopment()) // USe different error handling for development.
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseStaticFiles(); 

            app.UseRouting(); // ie allow us to append a URL?

            app.MapBlazorHub();

            app.MapFallbackToPage("/_Host");

            app.Run();
        }
    }
}