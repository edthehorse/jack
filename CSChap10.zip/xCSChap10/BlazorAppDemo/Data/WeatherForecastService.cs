namespace BlazorAppDemo.Data
{
    using System.Threading.Tasks;
    using System.Xml.Serialization;

    public class MyWeatherForecastService
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        //    //WeatherForecast[] v = X.Result.ToArray();
        //    //DateTime s2 = X.Result.ToArray()[0].Date;
        //    //Double v1 = v[1].TemperatureC;
        //    //Double v2 = v[1].TemperatureF; // method
        //    //string? s1 = v[0].Summary;


        Random r = new Random();
        public Task<WeatherForecast[]> GetForecastAsync(DateTime startDate) //startDate is Today.
        {
            int nx;
            
            var W = Task.FromResult(Enumerable.Range(1, 5).Select(x => { // Puts the Result (array of Weatherforecasts) into the Task.

                nx = r.Next(0, 9); // 0->9 ie 10 forecasts.

                return new WeatherForecast // ONE forecast.
                {
                    Date = startDate.AddDays(x), //Consective day.

                    TemperatureC = (int)(75.0 / 9.0 * (double)nx - 20.0),// corresponding temps -20  -> 55,
                                                                          
                    Summary = Summaries[nx] // and corresponding Summaries. 
                };

            }).ToArray());

            // .ToArray() must be attached to a Linq - not a variable which is the result of a
            // Linq. ie ToArray() is an extension method not a method.

            return W; // return type is Task<WeatherForecast[]> or just WeatherForecast[]. 

            //W:   Id = 0x00000193, Status = RanToCompletion, Result = "Data.WeatherForecast[]"   Task<BlazorAppDemo.Data.WeatherForecast[]>
        }




        // Here is an expanded view of the above
        public Task<WeatherForecast[]> GetTempForecastAsync(DateTime startDate) //startDate is Today.
        {
            int nx; WeatherForecast wf;

            IEnumerable<WeatherForecast> X = Enumerable.Range(1, 5).Select(x => { // x here is like a for loop x = 1  to 5. 
                                                                                  // Like a List.
                                                                                  // Select must have a return - unless theres only one statement in the braces.

                nx = r.Next(0, 9); // 0->9 ie 10 forecasts.

                wf = new WeatherForecast() // create ONE forecast.
                {
                    Date = startDate.AddDays(x), //Consective day.

                    TemperatureC = (int)(75.0 / 9.0 * (double)nx - 20.0),// corresponding temps -20  -> 55,

                    Summary = Summaries[nx] // and corresponding Summaries. 
                };

                return wf; // return ONE WeatherForecast object to the Select.
            });

            WeatherForecast[] Z = X.ToArray();

            Task<WeatherForecast[]> W = Task.FromResult(Z); // Produces a Task.

            return W; //  return the Task. ie Task<WeatherForecast[]>

            //W:   Id = 0x00000193, Status = RanToCompletion, Result = "Data.WeatherForecast[]"   Task<BlazorAppDemo.Data.WeatherForecast[]>
        }


        // ie the above returns an array of type WeatherForecast[]

        //public async Task<WeatherForecast[]> myGetForecastAsync(DateTime startDate) //startDate is Today.
        //{
        //WeatherForecast[] WFs = new WeatherForecast[5];

        //var rng = new Random();

        //for (int i = 1; i <= 5; i++) // 5 weather forecasts
        //{
        //    DateTime d = DateTime.Now.AddDays(i); // 5 consecutive days from now.
        //    int ndx = rng.Next(0, 90); // Random integers 0  -> 90 
        //    int t = (int)(75.0 / 99.0 * (double)(ndx) - 20.0); // corresponding temps -20  -> 55
        //    string s = Summaries[ndx / 10]; // eg Bracing. Summaries are in order cold-> hot.
        //    WeatherForecast w = new WeatherForecast { Date = d, TemperatureC = t, Summary = s };
        //    // ie the forecast for that day.
        //    WFs[i] = w;
        //}
        //await  WFs;
        //}

        public Task<WeatherForecast[]> GetForecastAsync4(DateTime startDate)
{
    Task<WeatherForecast[]> W = Task.FromResult(Enumerable.Range(1, 5).Select(index => new WeatherForecast
    {
        Date = startDate.AddDays(index),
        TemperatureC = Random.Shared.Next(-20, 55),
        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
    }).ToArray());

    return W;
}


    }
}



