﻿namespace LinqDictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> d = new Dictionary<string, string>();

            d["A"] = "11000"; d["B"] = "10011"; d["C"] = "01110"; d["D"] = "10010";

            foreach (KeyValuePair<string, string> kvp in d) // use  linq here? yes see later
            {
                if (kvp.Value == "11000")

                    Console.WriteLine(kvp.Key);
            }
        }
    }
}