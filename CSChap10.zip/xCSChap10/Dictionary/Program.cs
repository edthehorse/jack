﻿namespace Dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> codes = new Dictionary<string, string>(){ {"A","11000"}, {"B","10011"} ,{"C","01110"},{"D","10010"}
            
            };

            //foreach (KeyValuePair<string, string> kvp in codes) // use  linq here? yes see later
            //{
            //    if (kvp.Value == "10010")

            //        Console.WriteLine(kvp.Key);
            //}

            // To find  the key corresponding to 11000
            //var key = codes.Where(x => x.Value == "11000").ToList();
            //Console.WriteLine(key[0].Key);

            var key = codes.First().Key;

            Console.WriteLine( key);

        }
    }
}