﻿namespace FuncActionTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Func<int, bool> Sum = s => true;
            Console.WriteLine(Sum(10)); // -> 10

            //Predicate<int> Sum = s => s == 10; // < -A criterion.
            //Console.WriteLine(Sum(10)); //-> true




        }
    }
}