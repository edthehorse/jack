﻿namespace GenericExp
{
    class Program
    {
        public static void Main()
        {
            int r = push<int>(2);           Console.WriteLine(r); // implicit conversion

            string s = push<string>("ed");  Console.WriteLine(s);

        }
        //static void push<T>(T x)
        //{
        //    T y = x;
        //}

        static T push<T>(T x)
        {
            return x;
        }



        //public static void Main()
        //{
        //    int x = 2; int y = 3;
        //    Console.WriteLine($"x={x} y={y}");

        //    swap<int>(ref x, ref y);
        //    Console.WriteLine($"now x={x} y={y}");

        //    double u = 2.1; double v = 3.1;
        //    Console.WriteLine($"{u} {v}");

        //    swap<double>(ref u, ref v);
        //    Console.WriteLine($"{u} {v}");

        //    string s = "ed"; string t = "jo";
        //    Console.WriteLine($"{s} {t}");

        //    swap<string>(ref s, ref t);
        //    Console.WriteLine($"{s} {t}");
        //}

        static void swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }





    }
}
