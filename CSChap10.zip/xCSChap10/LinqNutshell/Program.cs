﻿namespace LinqNutshell
{

    using System;
    using System.Linq;

    internal class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Tom", "Dick", "Harry" };


         
          

            var filteredNames = names.Where(n => n.Length >= 4);
            
            foreach (string n in filteredNames)
                Console.WriteLine(n);

        }
    }
}