﻿namespace HTTPClient
{
	class test
	{
		struct IndexedWord { public string Word; public int Index; }
		public static async Task Main()
		{
			string wordLookupFile = Path.Combine(Path.GetTempPath(), "WordLookup.txt");

			// DICTIONARY wordLookupFile
			if (!File.Exists(wordLookupFile))    // Contains about 150,000 words
				File.WriteAllText(wordLookupFile, await new HttpClient().GetStringAsync( "http://www.albahari.com/ispell/allwords.txt"));
			
			var wordLookup = new HashSet<string>(File.ReadAllLines(wordLookupFile),	StringComparer.InvariantCultureIgnoreCase);

			// TESTDOC  wordsToTest
			var random = new Random();

			string[] wordList = wordLookup.ToArray();

			string[] wordsToTest = Enumerable.Range(0, 1000000) // Set of random nos 0->100000
				.Select(i => wordList[random.Next(0, wordList.Length)]) // Use a random no to select a word from the Dictionary.
				.ToArray();

			wordsToTest[12345] = "woozsh";     // Introduce a couple..
			wordsToTest[23456] = "wubsie";     // ..of spelling mistakes.

			var query = wordsToTest
				.AsParallel() // Parallel threads
				.Select((x, i) => new IndexedWord { Word = x, Index = i }) // Put them into the structure.
				.Where(x => !wordLookup.Contains(x.Word)) // where NOT true ie not there.
				.OrderBy(word => word.Index); // might as well sort them.

			//query.Dump();

			foreach (var v in query)
				Console.WriteLine(v.Word.ToString());
		}
	}
}