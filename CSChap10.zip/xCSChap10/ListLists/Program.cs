﻿namespace ListLists
{
    internal class Program
    {
        static void Main(string[] args)
        {

            List<List<string>> myList = new List<List<string>>();

            myList.Add(new List<string> { "a", "b" });
            myList.Add(new List<string> { "c", "d", "e" });
            myList.Add(new List<string> { "q", "a", "z" });
            myList.Add(new List<string> { "a", "b" });

            // To iterate over it: A loop inside a loop:
            foreach (List<string> subList in myList)
            {
                foreach (string item in subList)
                {
                    Console.Write($"{item} "); // 1 1Console.WriteLine();
                }
                Console.WriteLine();
            }

        }
    }
}