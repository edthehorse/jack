﻿using System.Diagnostics;


namespace AsyncMain
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var sw = new Stopwatch();
            sw.Start();

            Task task1 = f1(); // Task object will see over the async operation.
            Task task2 = f2(); // ie keep track of each one.
            Task task3 = f3();

            await Task.WhenAll(task1, task2, task3);

            sw.Stop();

            var elapsed = sw.ElapsedMilliseconds;
            Console.WriteLine($"elapsed: {elapsed} ms");
        }

        static async Task f1()
        {
            await Task.Delay(4000);
            Console.WriteLine("f1 finished");
        }
        static async Task f2()
        {
            await Task.Delay(7000);
            Console.WriteLine("f2 finished");
        }
        static async Task f3()
        {
            await Task.Delay(2000);
            Console.WriteLine("f3 finished");
        }
    }
}