﻿using System.ComponentModel;

namespace Func
{
    internal class Program
    {
        

           

        static void Main()
        {

            Func<int, int> sqr = x => x * x;
            int y = sqr(3);
            Console.WriteLine(y);

            // 1.Write our above delegate code to find the cube (of 3) rather than sqr 
            Func<int, int> cube = x => x * x * x;
            int c = cube(3);
            Console.WriteLine(c);

            //Exercise2: Write Func delegate code to input two ints and return the sum.
            Func<int,int,int> add = (x,y) => x+y;
            int z = add(3,4);
            Console.WriteLine(z);

            // 3. Make a Func delegate which inputs a string and finds its length.
            //Func<string, int> totalLength = (s) => s.Length;
            //int tot = totalLength("hello");
            //Console.WriteLine(tot);

            // 4 Make a Func delegate which inputs two strings and finds the total length of them.
            // Using multiple arguments:
            Func<string, string, int> totalLength = (s1, s2) => s1.Length + s2.Length;
            int tot = totalLength("hello", "world");
            Console.WriteLine(tot);

            // 5: Make a Func delegate which takes no input and returns a string
            // Zero arguments:
            Func<string> greeter = () => "Hello, world Again";
            Console.WriteLine(greeter());







        }
    }
}