﻿using System.Net.Http.Headers;

using Newtonsoft.Json;


namespace tests
{
    class Program
    {

        internal class Contributor
        {
            public string? Login { get; set; }
            public short Contributions { get; set; }

        }
        static async Task Main()
        {
            using var client = new HttpClient();

            client.BaseAddress = new Uri("https://api.github.com");

            client.DefaultRequestHeaders.Add("User-Agent", "C# console program"); // necessary!

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json")); // Tells it  json is used in request.#

            var url = "repos/symfony/symfony/contributors";

            HttpResponseMessage response = await client.GetAsync(url); // Hello Github!# https://api.github.com/repos/symfony/symfony/contributors #

            response.EnsureSuccessStatusCode();

            var resp = await response.Content.ReadAsStringAsync();// GetAsync above allowed us to get Content.

            Contributor? c1 = new Contributor();

            List<Contributor> contributors = JsonConvert.DeserializeObject<List<Contributor>>(resp); // Make into Json objects

            //foreach (var v in contributors)
            //    Console.WriteLine($"{v.Login} {v.Contributions} ");
        }

    }
}