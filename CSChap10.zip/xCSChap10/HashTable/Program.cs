﻿namespace HashTable
{
    using System;
    using System.Collections;

    class Test
    {
        static void Main()
        {
            Hashtable ht = new Hashtable();

            ht.Add("ed", 10);
            ht.Add(56, 20);

            Console.WriteLine(ht["ed"]);
        }
    }

}