﻿namespace ListPart
{
    internal class Program
    {
        class test
        {
        public class Part
        {
            public string? Name { get; set; }
            public int Age { get; set; }
        }public static void Main()
            {
                Part p1 = new Part { Name = "ed", Age = 42 };
                Part p2 = new Part { Name = "jo", Age = 44 };

                List<Part> people = new List<Part> { p1, p2 };

                foreach (var p in people)
                {
                    Console.WriteLine ($"{p.Name} {p.Age}");  
                }
            }
        }
    }
}
