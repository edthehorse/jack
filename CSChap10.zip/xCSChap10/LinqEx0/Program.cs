﻿namespace LinqEx0
{
    internal class Program
    {
        static void Main()
        {
            int[] nums = new int[7] { 3, 0, 1, 5, 6, 5, 1 };

            //A NUMBER
            var a = nums.Min();     // 0
            var b = nums.Count();   // 7
            var c = nums.Sum();     // 21
            var d = nums.Average(); // 3 

            //AN ELEMENT
            var e = nums.Last();        // 1
            var f = nums.First();           // 3  
            var g = nums.FirstOrDefault();  // 3 If array empty  -> 0
            var h = nums.ElementAt(0);  // 3   Not nums(0) :-(

            //A COLLECTION
            var i = nums.Append(7);          // 3, 0, 1, 5, 6, 5, 1, 7 
            var j = nums.Take(2);            // 3, 0 
            var k = nums.ToList();           // eg int x = k[0]; ->3
            var l = nums.Distinct();         // 3, 0, 1, 5, 6,  1 

            var m = Enumerable.Range(2, 7);        // 2 3 4 5 6 7 8 
            var n = Enumerable.Repeat<int>(10, 4); // 10 10 10 10 
        }

    }
}