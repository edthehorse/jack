﻿namespace LinqTest1
{
    internal class Program
    {
        static void Main()
        {
            string[] fruits = {"apple", "banana", "mango", "orange", "grape"};
            bool b = FindFruit("mango",fruits);
            Console.WriteLine(b);

            static bool FindFruit(string f, string[] fr)
            {
                bool fnd = false;
                foreach(string v in fr)
                {
                    if (v == f)
                    {
                        fnd = true;
                        break;
                    }
                }
                return fnd;
            }
        }
    }
}