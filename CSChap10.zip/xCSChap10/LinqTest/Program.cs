﻿namespace LinqTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> ages = new List<int> { 21, 46, 46, 55, 17, 21, 55, 55 };

            int[] grades = { 59, 82, 70, 56, 92, 82, 59 };

            string[] fruits = { "apple", "banana", "mango", "orange", "grape" };

            bool b = fruits.Contains("mango");

            Console.WriteLine(b);

            var firstThree = grades.Take(3); // -> 59 82 70 

            foreach (int grade in firstThree)
           
                Console.WriteLine(grade);
            }

            //var dist  = grades.Distinct();
            //         foreach (int g in dist)
            //         {
            //             Console.WriteLine(g);
            //         }
            //         int c = grades.Distinct().Count();
            //         Console.WriteLine(c);


            // EXERCISE 1 & 2:

            //var nums = grades.Where(x => x > 80);
            //// var nums = grades.Where(x => x > 80 && x < 90);
            //foreach (var n in nums)
            //{
            //    Console.Write($" {n}");
            //}

            // EXERCISE 3:

            

            //var v = fruits.Where(x => x.Length > 5);

            //foreach (var f in v)
            //{
            //    Console.Write($" {f}");
            //}
            //Console.WriteLine(fruits.OrderBy(n => n.Length).Count());


            //var v = fruits.OrderBy(n => n);


            //    Dictionary<string, string> d = new Dictionary<string, string>();
            //    d["A"] = "11000"; d["B"] = "10011"; d["C"] = "01110"; d["D"] = "10010";
            //var k = d.Where(x => x.Value == "11000").ToList();
            //foreach (var v in k) Console.WriteLine(v.Key); // ->A


            //var v = Enumerable.Range(1, 10).Select(x => x * x).ToArray();
            //Console.WriteLine(v[2]);


            //foreach (var f in v)
            //{
            //    Console.Write($" {f}");
            //}
        }
    }
    }
