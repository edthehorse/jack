﻿namespace QuerySyntax
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[7] { 0, 4, 1, 5, 6, 5, 2 };

            var numQuery = from num in numbers where (num > 3) select num;   //  -> 4 5 6 5

        }
    }
}