﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LinqFruit
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //Exercise 0: Write code to output the above  names:   
        private void Print_Click(object sender, RoutedEventArgs e)
        {
            string[] names = { "Tom", "Dick", "Harry" };

            foreach (var fn in names)
            {
                Console.WriteLine(fn);
            }
        }
        
        
        
        // Exercise 1: Write code to output the above sorted names:
        private void OrderBy_Click(object sender, RoutedEventArgs e)
        {
            string[] names = { "Tom", "Dick", "Harry" };

            var filteredNames = names.OrderBy(n => n);

            foreach (var fn in filteredNames)
            {
                Console.WriteLine(fn);
            }
        }

   // Exercise 1a: Sort theM alphabetically descending and print them.
        private void Descending_Click(object sender, RoutedEventArgs e)
        {
            string[] names = { "Tom", "Dick", "Harry" };

            var filteredNames = names.OrderByDescending(n => n);

            foreach (var fn in filteredNames)
            {
                Console.WriteLine(fn);
            }
        }
    // Exercise 2: Sort these below by length (see above) ascending and print them out.
        private void Length_Click(object sender, RoutedEventArgs e)
        {
            string[] fruits = { "apple", "banana", "mango", "orange", "grape" };

            var v = fruits.OrderBy(n => n.Length);

            foreach (var f in v)
            {
                Console.Write($" {f}");
            }
        }
        // Exercise 3: Make a sorted ascending list of fruit names of length >5 and print them out.
        private void Greater5_Click(object sender, RoutedEventArgs e)
        {
            string[] fruits = { "apple", "banana", "mango", "orange", "grape" };

            var v = fruits.Where(x => x.Length > 5).OrderBy(n => n);

            foreach (var f in v)
            {
                Console.Write($" {f}");
            }
        }

        // Exercise 4: Find the number of sorted fruit names of length >5.
        private void Number_Click(object sender, RoutedEventArgs e)
        {

            string[] fruits = { "apple", "banana", "mango", "orange", "grape" };

            var n = fruits.Where(x => x.Length > 5).OrderBy(n => n).Count();


 
                Console.Write($" {n}");
            }

       
  // Exercise 5. Use Select to produce squares from 1 –> 10   ie 1  4  9 , etc.
        private void Select_Click(object sender, RoutedEventArgs e)
        {
            var v = Enumerable.Range(1, 10).Select(x => x * x);

            foreach (var f in v)
            {
                Console.Write($" {f}");
            }
        }
        //Exercise 6. Place the above elements in an array.Print out the 3rd element for example.
        private void Array_Click(object sender, RoutedEventArgs e)
        {

            //var v = Enumerable.Range(1, 10).Select(x => x * x);


            var v = Enumerable.Range(1, 10).Select(x => x * x).ToArray();

            Console.WriteLine(v[2]);
        }
    }
}
