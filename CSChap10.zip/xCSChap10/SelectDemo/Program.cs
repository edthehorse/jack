﻿using System.Runtime.CompilerServices;

namespace SelectDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int y;
            IEnumerable<int> squares = Enumerable.Range(1, 10).Select(x => return  { x * x}); 

            foreach (int num in squares)
            {
                Console.WriteLine(num);
            }
        }
    }
}


