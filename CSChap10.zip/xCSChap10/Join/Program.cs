﻿using System;
using System.Linq;

class Program
{
	static void Main()
	{
		// Array 1.
		var ints1 = new int[3];
		ints1[0] = 4; // Matches 5 so select it. (The order doesn have to corespond!)
		ints1[1] = 3; // Matches 4 so select it.
		ints1[2] = 0;

		// Array 2.
		var ints2 = new int[3];
		ints2[0] = 5;
		ints2[1] = 6;
		ints2[2] = 4;

		{
			// Join with method call. 
			var result = ints1.Join<int, int, int, int>(ints2, // ints2 is the outer set.
			x => x + 1,  // inner key. 4 matches 5  and 3 matches 4
			y => y, // outer key ie defines the outer (2nd) set variable. (x was the inner set variable.)
			(x, y) => x); // result is x ie 4 3  (Could be y which gives 5 4).
			// (x is inner set . y is outer set.)

			// Display results.
			foreach (var r in result)
			{
				Console.Write($" {r}"); // 4 3 
			}
		}

		Console.WriteLine();


		{
			// Does same thing. Join with query expression (rather than method as above), 
			var result = from t in ints1
						 join x in ints2 on (t + 1) equals x
						 select t;

			// Display results.
			foreach (var r in result)
			{
				Console.Write($" {r}"); // 4 3
			}
		}
	}
}