﻿
class Program
{
    public static void Main()
    {
     push<int,string>(2,"ed");
    }
    public static void push<T, U>(T x, U y)
    {
    }
}
