﻿namespace LambdaBasic
{
    internal class Program
    {
       
       delegate int Transformer(int i); // Declare a delegate – and its signature

        static void Main(string[] args)
        {

            //Transformer sqr = (int x) => (int)x * x;    // Assign our delegate instance to our lambda expression. 
         
            //Func<int, int> sqr = x => x * x;
            var sqr = (int x) => x * x;
            int y = sqr(3);// Evaluate it.
            Console.WriteLine(y);

            //Transformer cube = (int x) => (int)x * x * x;    // Assign our delegate instance to our lambda expression. 
            Func<int, int> cube = x => x * x;
                y = cube(3);              // Evaluate it.
            Console.WriteLine(y);










        }
    }
}