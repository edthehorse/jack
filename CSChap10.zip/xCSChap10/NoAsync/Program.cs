﻿using System.Diagnostics;

namespace NoAsync
{
    class Program
    {
        static void Main()
        {
            var sw = new Stopwatch();

            sw.Start();

            f1();
            f2();
            f3();

            sw.Stop();

            var elapsed = sw.ElapsedMilliseconds;
            Console.WriteLine($"elapsed: {elapsed} ms");
        }
        static void f1()
        {
            Console.WriteLine("f1 called");
            Thread.Sleep(4000);
        }

        static void f2()
        {
            Console.WriteLine("f2 called");
            Thread.Sleep(7000);
        }

        static void f3()
        {
            Console.WriteLine("f3 called");
            Thread.Sleep(2000);
        }
    }
}