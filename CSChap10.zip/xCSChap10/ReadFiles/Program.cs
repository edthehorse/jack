﻿

namespace ReadFiles
{
    internal class Program
    {
        static  async Task Main()
        {
            var task1 = File.ReadAllTextAsync(@"C:\X\data1.txt");
            var task2 = File.ReadAllTextAsync(@"C:\X\data2.txt");
            var task3 = File.ReadAllTextAsync(@"C:\X\data3.txt");
            var task4 = File.ReadAllTextAsync(@"C:\X\data4.txt");

            var tasks = new Task[] { task1, task2, task3, task4 };

            Task.WaitAll(tasks); // Necessary?

            var content1 = await task1;
            var content2 = await task2;
            var content3 = await task3;
            var content4 = await task4;

            Console.WriteLine(content1.TrimEnd());
            Console.WriteLine(content2.TrimEnd());
            Console.WriteLine(content3.TrimEnd());
            Console.WriteLine(content4.TrimEnd());
        }
    }
}