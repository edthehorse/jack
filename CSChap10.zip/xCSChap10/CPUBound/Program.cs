﻿namespace CPUBound
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            var tasks = new List<Task<int>>();

            tasks.Add(Task.Run(() => DoWork1()));
            tasks.Add(Task.Run(() => DoWork2()));

            await Task.WhenAll(tasks);

            Console.WriteLine(await tasks[0]);
            Console.WriteLine(await tasks[1]);

            async Task<int> DoWork1()
            {
                var text = string.Empty;

                for (int i = 0; i < 100_000; i++)
                {
                    text += "abc";
                }

                Console.WriteLine("concatenation finished");

                return await Task.FromResult(text.Length);
            }

            async Task<int> DoWork2()
            {
                var text = string.Empty;

                for (int i = 0; i < 100_000; i++)
                {
                    text = $"{text}abc";
                }

                Console.WriteLine("interpolation finished");

                return await Task.FromResult(text.Length);
            }
        }
    }
}