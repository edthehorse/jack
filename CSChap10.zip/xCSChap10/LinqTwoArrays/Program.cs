﻿namespace LinqTwoArrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            static void Main()
            {
                int[] nums = new int[7] { 3, 0, 1, 5, 6, 5, 1 };
                int[] num1 = new int[3] { 5, 1, 8 };

                //COLLECTION
                var a = nums.Concat(num1);  //3, 0, 1, 5, 6, 5, 1 5, 1, 8
                var b = nums.Union(num1);     //3, 0, 1, 5, 6,  8
                var c = nums.Intersect(num1); //1, 5

            }

        }
    }
}