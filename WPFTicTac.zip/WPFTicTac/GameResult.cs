﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFTicTac
{
    public class GameResult
    {
        public Player Winner { get; set; }// X or O.
        public WinInfo WinInfo { get; set; }
    }
}
