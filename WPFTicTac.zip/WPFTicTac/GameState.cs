﻿using System;

namespace WPFTicTac
{
    public class GameState
    { // Array operations/
        public Player[,] GameGrid { get; private set; }  // contains X,O,diag,none.
        public Player CurrentPlayer { get; private set; }// X,O,diag,none
        public int TurnsPassed { get; private set; } // How many goes so far.
        public bool GameOver { get; private set; }// Yes or no.

        public event Action<int, int> MoveMade; // When a move has been made...

        public event Action<GameResult> GameEnded;  // This event fires when the game is ended.

        public event Action GameRestarted; // This event fires when the game is restarted.

        public GameState() // Constructor sets up board and initial player etc.
        {
            GameGrid = new Player[3, 3]; // Array to contain X's and O's (or Nones).

            CurrentPlayer = Player.X; // Player X starts.

            TurnsPassed = 0;          // No goes yet.

            GameOver = false;
        }

        private bool CanMakeMove(int r, int c) // ie if theres an empty spot.
        {
            return !GameOver && GameGrid[r, c] == Player.None; // !GameOver and square is not empty.
        }

        private bool IsGridFull() // If end of the game - winner or not.
        {
            return TurnsPassed == 9; // Adios.
        }

        private void SwitchPlayer() // X<->O.
        {
            CurrentPlayer = CurrentPlayer == Player.X ? Player.O : Player.X;
        }

        private bool AreSquaresMarked((int, int)[] squares, Player player)
        {
            foreach ((int r, int c) in squares) // All squares. Tuple?
            {
                if (GameGrid[r, c] != player) // e X nor O nor None.
                {
                    return false;
                }
            }

            return true;// True if all marked ie game over.
        }

        private bool DidMoveWin(int r, int c, out WinInfo winInfo) // Check for winning combo.
        {
            (int, int)[] row = new[] { (r, 0), (r, 1), (r, 2) };      // row win scenario.
            (int, int)[] col = new[] { (0, c), (1, c), (2, c) };      // col win scenario.
            (int, int)[] mainDiag = new[] { (0, 0), (1, 1), (2, 2) }; // diag win scenario.
            (int, int)[] antiDiag = new[] { (0, 2), (1, 1), (2, 0) }; // diag win scenario.

            if (AreSquaresMarked(row, CurrentPlayer)) // For row win.
            {
                winInfo = new WinInfo { Type = WinType.Row, Number = r };

                return true;
            }

            if (AreSquaresMarked(col, CurrentPlayer))
            {
                winInfo = new WinInfo { Type = WinType.Column, Number = c };// For col win.

                return true;
            }

            if (AreSquaresMarked(mainDiag, CurrentPlayer))// For diag win.
            {
                winInfo = new WinInfo { Type = WinType.MainDiagonal };

                return true;
            }

            if (AreSquaresMarked(antiDiag, CurrentPlayer))// For antidiag win.
            {
                winInfo = new WinInfo { Type = WinType.AntiDiagonal };

                return true;
            }

            winInfo = null;

            return false;
        }

        private bool DidMoveEndGame(int r, int c, out GameResult gameResult)
        {
            if (DidMoveWin(r, c, out WinInfo winInfo))
            {
                gameResult = new GameResult { Winner = CurrentPlayer, WinInfo = winInfo };

                return true;
            }

            if (IsGridFull())
            {
                gameResult = new GameResult { Winner = Player.None };

                return true; // Game over
            }

            gameResult = null;

            return false;
        }

        public void MakeMove(int r, int c)// Set the X's and O's.
        {
            if (!CanMakeMove(r, c))
            {
                return; // Cant move
            }

            GameGrid[r, c] = CurrentPlayer;

            TurnsPassed++;

            if (DidMoveEndGame(r, c, out GameResult gameResult))
            {
                GameOver = true;

                MoveMade?.Invoke(r, c);

                // Above is equivalent to
                // If (MoveMade != null) // Checks if there is a handler.
                {
                    // MoveMade(r,c) // Calls it if there is.
                }

                GameEnded?.Invoke(gameResult); // ** calls a method in another class: MainWindow.
            }
            else
            {
                SwitchPlayer();
                MoveMade?.Invoke(r, c);
            }
        }

        public void Reset()// New Game.
        {
            GameGrid = new Player[3, 3]; 

            CurrentPlayer = Player.X; // X starts.

            TurnsPassed = 0;

            GameOver = false;

            GameRestarted?.Invoke(); // Call GameRestarted event.
        }
    }
}
