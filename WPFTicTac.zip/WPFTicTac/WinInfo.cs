﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFTicTac
{

    // Used to supply a green strike-thru line.
    public class WinInfo
    {
        public WinType Type { get; set; }// Row,column, diag , none
        public int Number { get; set; }// No. of the row/column.
    }
}
