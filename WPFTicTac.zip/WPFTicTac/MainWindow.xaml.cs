﻿using System;
using System.Collections.Generic;

using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

using System.Windows.Shapes;

namespace WPFTicTac
{
    // Contains 
    public partial class MainWindow : Window
    {
        // Dictionary for each player's image. ANIMATION IMAGES.
        private readonly Dictionary<Player, ImageSource> imageSources = new()
        {  // (Here we use an absolute pack uri instead of relative.)
            { Player.X, new BitmapImage(new Uri("pack://application:,,,/Assets/X15.png")) },
            { Player.O, new BitmapImage(new Uri("pack://application:,,,/Assets/O15.png")) }
        };

        private readonly Dictionary<Player, ObjectAnimationUsingKeyFrames> animations = new()
        {
            { Player.X, new ObjectAnimationUsingKeyFrames() },
            { Player.O, new ObjectAnimationUsingKeyFrames() }
        };

        private readonly DoubleAnimation fadeOutAnimation = new DoubleAnimation
        {  
            Duration = TimeSpan.FromSeconds(.5), // Game emded?
            From = 1,
            To = 0
        };

        private readonly DoubleAnimation fadeInAnimation = new DoubleAnimation
        {
            Duration = TimeSpan.FromSeconds(.5),// Game started?
            From = 0,
            To = 1
        };

        // The grid:
        private readonly Image[,] imageControls = new Image[3, 3];

        private readonly GameState gameState = new GameState(); // ** Can now access methods etc of GameState.cs.

        public MainWindow()
        {
            InitializeComponent();

            SetupGameGrid();   // Step 1 : Set up a 9x9 array of image holders. ** Not nec to call async.Cause we are calling the GUI.

            SetupAnimations(); // Dont actually animate. Just set it up. X's and O's here only.

            gameState.MoveMade += OnMoveMade; // Register the event handlers.**
            // Event handlers are below ie in this class. These are the methods that can be called from another class.
            // ie from Main! *We cant create an object of Main thats why we must (can) use EVENTS !
            gameState.GameEnded += OnGameEnded;

            gameState.GameRestarted += OnGameRestarted;
        }
        private void SetupGameGrid()
        {
            for (int r = 0; r < 3; r++)
            { 
                // Sets up 9 image controls - not images!
                for (int c = 0; c < 3; c++)
                {
                    Image imageControl = new Image();

                    GameGrid.Children.Add(imageControl);

                    imageControls[r, c] = imageControl;
                }
            }
        }

        private void SetupAnimations() // Animate the X's and O's (Only).
        {
            animations[Player.X].Duration = TimeSpan.FromSeconds(.25); // animations is a dictionary.

            animations[Player.O].Duration = TimeSpan.FromSeconds(.25); // contains ObjectAnimationUsingKeyFrames objects.
            // So we here set the repective durations of the ObjectAnimationUsingKeyFrames objects.
            // ie .25 sec between each animation? Total duration?

            for (int i = 0; i < 16; i++) // 16 actual images for each of X and O respectively to animate.
            {
                // X's

                Uri xUri = new Uri($"pack://application:,,,/Assets/X{i}.png"); // Location of X1.png etc.

                BitmapImage xImg = new BitmapImage(xUri); // Get the next image.

                DiscreteObjectKeyFrame xKeyFrame = new DiscreteObjectKeyFrame(xImg);

                animations[Player.X].KeyFrames.Add(xKeyFrame); // Load up the animations.

                // O's

                Uri oUri = new Uri($"pack://application:,,,/Assets/O{i}.png"); // Location of O1.png etc.

                BitmapImage oImg = new BitmapImage(oUri);

                DiscreteObjectKeyFrame oKeyFrame = new DiscreteObjectKeyFrame(oImg);

                animations[Player.O].KeyFrames.Add(oKeyFrame);
            }
        }

        private async Task FadeOut(UIElement uiElement) // End of game ?
        {
            uiElement.BeginAnimation(OpacityProperty, fadeOutAnimation);

            await Task.Delay(fadeOutAnimation.Duration.TimeSpan);

            uiElement.Visibility = Visibility.Hidden;
        }

        private async Task FadeIn(UIElement uiElement)  // Start of game ?
        {
            uiElement.Visibility = Visibility.Visible;

            uiElement.BeginAnimation(OpacityProperty, fadeInAnimation);

            await Task.Delay(fadeInAnimation.Duration.TimeSpan);
        }

        private async Task TransitionToEndScreen(string text, ImageSource winnerImage) // Fade out when game over.
        {
            await Task.WhenAll(FadeOut(TurnPanel), FadeOut(GameCanvas));

            ResultText.Text = text;

            WinnerImage.Source = winnerImage;

            await FadeIn(EndScreen);
        }

        private async Task TransitionToGameScreen() // Fade in to the game.
        {
            await FadeOut(EndScreen);

            Line.Visibility = Visibility.Hidden;    // Hide the line.

            await Task.WhenAll(FadeIn(TurnPanel), FadeIn(GameCanvas));
        }

        private (Point, Point) FindLinePoints(WinInfo winInfo) // ie Get the coords (tuple!) to draw the line for the winner.
        { // eg     (tuple)                         0, Antidiagonal
            double squareSize = GameGrid.Width / 3; // Each square - size 100

            double margin = squareSize / 2;

            if (winInfo.Type == WinType.Row)  // If it was a row win. Which row to draw the line.
            {
                double y = winInfo.Number * squareSize + margin; // winInfo.Number is Which row to draw the line.

                return (new Point(0, y), new Point(GameGrid.Width, y));  // Return the end coords.
            }

            if (winInfo.Type == WinType.Column)// If it was a column win. 
            {
                double x = winInfo.Number * squareSize + margin; // winInfo.Number is Which column to draw the line.

                return (new Point(x, 0), new Point(x, GameGrid.Height)); // Return the end coords.
            }

            if (winInfo.Type == WinType.MainDiagonal)
            {
                return (new Point(0, 0), new Point(GameGrid.Width, GameGrid.Height)); // Return the end coords.
            }

            return (new Point(GameGrid.Width, 0), new Point(0, GameGrid.Height)); // else antidiagonal 
            //  ie                  300,0                       0,300                   
        }

        private async Task ShowLine(WinInfo winInfo) // Draws an animated line.
        { // (This time its the top row:) 
            (Point start, Point end) = FindLinePoints(winInfo); // tuple
            // 0,50          300,50
            Line.X1 = start.X; // 0
            Line.Y1 = start.Y; // 50

            DoubleAnimation x2Animation = new DoubleAnimation // Animate the line.
            {
                Duration = TimeSpan.FromSeconds(.25), // Lasts for 1/4 sec.
                From = start.X, //   0
                To = end.X      // 300
            };

            DoubleAnimation y2Animation = new DoubleAnimation // Animate the line.
            {
                Duration = TimeSpan.FromSeconds(.25),
                From = start.Y,  // 50
                To = end.Y       // 50
            };

            Line.Visibility = Visibility.Visible;

            Line.BeginAnimation(Line.X2Property, x2Animation); // Animate the line.

            Line.BeginAnimation(Line.Y2Property, y2Animation);

            await Task.Delay(x2Animation.Duration.TimeSpan);   // .25 sec
        }

        // EVENT HANDLERS
        private void OnMoveMade(int r, int c)
        {
            Player player = gameState.GameGrid[r, c]; // Check the player who marked it last (ie made the last move).

            imageControls[r, c].BeginAnimation(Image.SourceProperty, animations[player]);

            PlayerImage.Source = imageSources[gameState.CurrentPlayer]; // Show current player.
        }

        private async void OnGameEnded(GameResult gameResult)
        {
            await Task.Delay(1000);     // Delay of 1 sec.

            if (gameResult.Winner == Player.None)
            {
                await TransitionToEndScreen("It's a tie!", null); // Animate to the end screen.
            }
            else
            {
                await ShowLine(gameResult.WinInfo); // Draw green line thru winning combo.

                await Task.Delay(1000); // Delay of 1 sec. ** To take a look at the screen result!

                await TransitionToEndScreen("Winner:", imageSources[gameResult.Winner]);
            }
        }

        private async void OnGameRestarted()
        {
            for (int r = 0; r < 3; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    imageControls[r, c].BeginAnimation(Image.SourceProperty, null);
                    imageControls[r, c].Source = null;
                }
            }

            PlayerImage.Source = imageSources[gameState.CurrentPlayer];
            await TransitionToGameScreen();
        }

        private void GameGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            double squareSize = GameGrid.Width / 3; // 300/3 = 100

            Point clickPosition = e.GetPosition(GameGrid);// Mouse coords.

            int row = (int)(clickPosition.Y / squareSize); // In WPF top to bottom.

            int col = (int)(clickPosition.X / squareSize); // Left to Right.

            gameState.MakeMove(row, col);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (gameState.GameOver)
            {
                gameState.Reset();
            }
        }
    }
}
