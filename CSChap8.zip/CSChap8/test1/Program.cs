﻿namespace test1
{
    internal class Program
    {



        public static void Main()
        {
            var x = default;

            Console.WriteLine(x);
          
        }
    }

}