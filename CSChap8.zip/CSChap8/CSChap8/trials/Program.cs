﻿namespace trials
{
    internal class Program
    {
        static void Main(string[] args)
        {
            T[] InitializeArray<T>(int length, T initializeValue = default!) // ie must be one or the other - true or false.
            {
                if (length < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(length), "Array length must be nonnegative.");
                }

                var array = new T[length]; // Make an array of a variable lenth.
                for (var i = 0; i < length; i++) // and fill it with that many variables.
                {
                    array[i] = initializeValue; // could be integer/ boolean/ etc.
                }
                return array;
            }

            void Display<T>(T[] values) => Console.WriteLine($"[ {string.Join(", ", values)} ]"); // Why is this inside Main()? No static?
           
            Display(InitializeArray<int>(3));  // output: [ 0, 0, 0 ]// First ints...
            
            Display(InitializeArray<bool>(4, default));  // Output: [ False, False, False, False ] // .. and then bools.

            System.Numerics.Complex fillValue = default;

            Display(InitializeArray(3, fillValue));  // Output: [ (0, 0), (0, 0), (0, 0) ]

        }
    }
}