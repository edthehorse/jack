﻿namespace FuncDemo
{
    internal class Program
    {
        public static void Main()
        {
            Func<int, int, int> add = delegate (int x, int y)
            {
                return x + y;
            };

            Func<int, int, int> sub = delegate (int x, int y)
            {
                return x - y;
            };

            Console.WriteLine(add(6, 2));
            Console.WriteLine(sub(6, 2));

        }

    }
}