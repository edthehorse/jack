namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "OK";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Shown(object sender, EventArgs e)
        {

            lbxBooks.Items.AddRange(new String[] { "Beginning C# by Wrox",
            "Professional C# by Wrox", "Programming C# by O' Reilly",
            "Professional ASP.Net", "Beginning Java 2 by Wrox",
            "C++ - The complete Reference", "Java Servlets Programming",
            "Java Server Pages - JSP)"});


        }
    }
}