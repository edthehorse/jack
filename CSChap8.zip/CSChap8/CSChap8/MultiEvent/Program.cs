﻿namespace MultiEvent
{
    using System;
    public class Program
    {
        class Part
        {
            public delegate void Mydel(string s);
            public event Mydel del;
            public void ask()
            { del("hello from Part"); }
        }

        public static void Main()
        {
            Part p = new Part();
            p.del += eddo;
            p.del += dodo;
            p.ask();
        }

        static void eddo(string s)
        { Console.WriteLine("{0} eddo", s); }

        static void dodo(string s)
        { Console.WriteLine("{0} dodo", s); }

    }

}