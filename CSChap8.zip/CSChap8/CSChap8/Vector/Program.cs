﻿namespace Vector
{
    internal class Program
    {

        public class Vector3
        {
            public double x1 { get; set; }
            public double x2 { get; set; }
            public double x3 { get; set; }
            public Vector3()
            {
                x1= 0;
                x2= 0;
                x3= 0;
            }

            public Vector3(double _x1, double _x2,double _x3)
            {
                x1= _x1;
                x2= _x2;
                x3= _x3;
            }
            public double Normal()
            {
                double d = x1 * x1 + x2 * x2 + x3 * x3;

                return Math.Sqrt(d);
            }

            public Vector3 Normalize()
            {
                double d = x1 * x1 + x2 * x2 + x3 * x3;

                Vector3 v = new Vector3();

                // v= vector divided by size. ie we need / operator.

                return v;
            }

            public static Vector3 operator + (Vector3 v1,Vector3 v2)
            {
                Vector3 v = new Vector3();

                v.x1 = v1.x1 + v2.x1;
                v.x2 = v1.x2 + v2.x2;
                v.x3 = v1.x3 + v2.x3;
                return v;
            }

        static void Main(string[] args)
        {
            Vector3 origin = new Vector3(3f, 4f, 12f);
            Vector3 target = new Vector3(3f, 4f, 12f);

            double sz = origin.Normal();

            // diff.Normalize()  requires us to return a new vector which was of size sz.

            Console.WriteLine(sz);
        }
    }
}