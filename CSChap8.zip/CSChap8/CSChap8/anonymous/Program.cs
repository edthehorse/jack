﻿namespace anonymous
{
    using System;
    public class Program
    {
        delegate void Mydel(int x, int y);

        public static void Main()
        {

            Mydel arith;

            arith =  delegate (int x, int y)
            {
                Console.WriteLine(x + y);
            };


            arith += delegate (int x, int y)
            {
                Console.WriteLine(x - y);
            };

            arith(6, 2);

        }
    }

}