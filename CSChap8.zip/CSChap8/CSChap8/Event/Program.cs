﻿using System;

public class Program
{
    class Part
    {
        public delegate void Mydel(string s); // declare a delegate type

        public event Mydel del = default!; /// declare our delegate in an event.
        public void ask()
        {            del("hello from Part");        }
    }

    public static void Main()
    {
        Part p = new Part();
        p.del += eddo;
        p.ask(); //sets off the event.
        Console.ReadLine();
    }

    static void eddo(string s)
    {        Console.WriteLine(s);    }

}
