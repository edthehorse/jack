﻿namespace DelCallBack
{
    using System;
    public class Program
    {
        class Part
        {
            public delegate void Mydel(string s);

            private Mydel del=default!;

            public void reg(Mydel d)
            {                del = d;            }
            public void ask()
            {          del("hello from Part");            }
        }

        public static void Main()
        {
            Part p = new Part();

            p.reg(eddo);

            p.ask();
        }

        static void eddo(string s)
        {
            Console.WriteLine(s);
        }
    }

}