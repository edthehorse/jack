﻿using System;


namespace Exercises
{

    //    public class Program // Function1
    //    {
    //        delegate void Mydel();

    //        public static void Main()
    //        {
    //            String? s;

    //            s = Console.ReadLine();

    //            Mydel chooseFunc;

    //            if (s == "Function1")
    //            {
    //                chooseFunc = Function1;
    //                chooseFunc();
    //            }

    //            if (s == "Function2")
    //            {
    //                chooseFunc = Function2;
    //                chooseFunc();

    //            }

    //            Console.ReadLine();
    //        }

    //        static void Function1()
    //        {
    //            Console.WriteLine("You called Function1");
    //        }

    //        static void Function2()
    //        {
    //            Console.WriteLine("You called Function2");
    //        }
    //    }

    #region Dodo as well
    //public class Program // Dodo as well
    //{
    //    class Part
    //    {
    //        public delegate void Mydel(string s); // declare a delegate type

    //        public event Mydel del = default!; /// declare our delegate in an event.

    //        public void ask()
    //        {
    //            del("hello from Part");
    //        }
    //    }

    //    public static void Main()
    //    {
    //        Part p = new Part();
    //        p.del += eddo;
    //        p.del += dodo;

    //        p.ask(); //Sets off the event. Unwinds - calls eddo then dodo.

    //    }
    //    static void dodo(string s)
    //    {
    //        Console.WriteLine(s + "Dodo");
    //    }
    //    static void eddo(string s)
    //    {
    //        Console.WriteLine(s + "Eddo");
    //    }
    //} 
    #endregion

    #region objectsource
    //public class Program
    //{
    //    class Part
    //    {
    //        public delegate void Mydel(object source, string s);

    //        public event Mydel del = default!;

    //        public void ask()
    //        {
    //            del(this, "hello from Part");
    //        }
    //    }

    //    public static void Main()
    //    {
    //        Part p = new Part();

    //        p.del += eddo;

    //        p.ask();

    //        Console.ReadLine();
    //    }

    //    static void eddo(object source, string s)
    //    {
    //        Console.WriteLine(source.GetType());
    //    }
    //} 
    #endregion













}

