﻿namespace Indexer
{
    using System;

    class Part
    {
        private int[] arr = new int[100];

        public int this[int nx]
        {
            get   {    return arr[nx];      }

            set   {    arr[nx] = value;     }
        }
    }
    class app
    {
        static void Main()
        {
            Part p = new Part();

            p[0] = 1;
            System.Console.WriteLine(p[0]);
            p[1] = 2;
            System.Console.WriteLine(p[1]);
        }
    }

}