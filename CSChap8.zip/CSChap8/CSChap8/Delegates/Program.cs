﻿namespace Delegates
{
    public class Program
    {
        delegate void Mydel(int x, int y);

        public static void Main()
        {
            Mydel arith = add;

            arith += sub;

            arith(6, 2);
        }

        static void add(int x, int y)
        {
            Console.WriteLine(x + y);
        }

        static void sub(int x, int y)
        {
            Console.WriteLine(x - y);
        }
    }

}


