﻿using System;
class test
{
    public class Coords
    {
        public double x { get; set; }
        public double y { get; set; }

        public Coords()
        {   x = 0; y = 0;   }

        public Coords(double a, double b)
        {  x =  a;   y = b;      }
        public static Coords operator +(Coords p1, Coords p2)
        {
            Coords p = new Coords();
            p.x = p1.x + p2.x;
            p.y = p1.y + p2.y;
            return p;
        }

        public void printout()
        {
            Console.WriteLine("{0,2} \n{1,2}\n", x, y);
        }
    }
    static void Main()
    {
        Coords p1 = new Coords(1, 2);
        p1.printout();

        Coords p2 = new Coords(2, 1);
        p2.printout();

        Coords p3 = new Coords();
        p3.printout();


        p1 = p1 + p2;
    

        p3.printout();
    }
}
