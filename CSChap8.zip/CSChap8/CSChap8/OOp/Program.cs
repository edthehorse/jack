﻿namespace OOp
{
    class app
    {
        class Part
        {
            public int i
            { get; set; }

            public static Part operator +(Part a, Part b)
            {
                Part p = new Part();
                p.i = a.i + b.i;
                return p;
            }

            public static Part operator -(Part a, Part b)
            {
                Part p = new Part();
                p.i = a.i - b.i;
                return p;
            }
        }

        static void Main()
        {
            Part p1 = new Part() { i = 1 };
            Part p2 = new Part() { i = 2 };
            Part p3 = new Part { i = 0 }; 

            p3 +=  p1; // p3= p3+p1;
            p3 -=  p1;
            Console.WriteLine(p3.i);
        }
    }

}