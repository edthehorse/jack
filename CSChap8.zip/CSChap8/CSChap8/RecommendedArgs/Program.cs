﻿
using System;

namespace RecommendedArgs
{
    public class MyArgs : EventArgs
    {
        public String s;
        public MyArgs(string _s) // Constructor
        {            s = _s;        }
    }
    public class Program
    {
        class Part
        {
            public delegate void Mydel(MyArgs e);

            public event Mydel del = default!;

            MyArgs m = new MyArgs("hello from Part");

            public void ask()
            {                del(m);            }
        }
        public static void Main()
        {
            Part p = new Part();

            p.del += eddo;

            p.ask();

          
        }

        static void eddo(MyArgs e)
        {
            Console.WriteLine(e.s);
        }
    }
}